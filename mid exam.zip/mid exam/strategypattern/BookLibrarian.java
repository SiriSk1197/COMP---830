package strategypattern;
import java.util.ArrayList;
import java.util.Collections;

public interface BookLibrarian {
	public void setSortMethod(ArrayList bookObjects);
}
