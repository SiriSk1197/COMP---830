package question3;

public interface BakedGoods {

	public int getPrice();
	
	public String getDescription();

	public String getSellByDate();
	
}
